public class Appointment {
    private String patientName;
    private String patientPhone;
    private String timeSlot;
    private HealthProfessional doctor;

    public Appointment() {
        this.patientName = "";
        this.patientPhone = "";
        this.timeSlot = "";
        this.doctor = new HealthProfessional();
    }

    public Appointment(String patientName, String patientPhone, String timeSlot, HealthProfessional doctor) {
        this.patientName = patientName;
        this.patientPhone = patientPhone;
        this.timeSlot = timeSlot;
        this.doctor = doctor;
    }

    public void printAppointmentInfo() {
        System.out.println("=== 预约详情 ===");
        System.out.println("患者姓名：" + patientName);
        System.out.println("患者手机：" + patientPhone);
        System.out.println("预约时间段：" + timeSlot);
        System.out.println("预约医生信息：");
        doctor.printInfo();
    }

    public String getPatientPhone() {
        return patientPhone;
    }
}