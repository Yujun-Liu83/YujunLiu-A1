/**
 * Class representing a patient appointment
 * Stores patient details, appointment time, and associated doctor
 */
public class Appointment {
    // Marked as final (does not modify after initialization)
    private final String patientName;
    private final String patientPhone;
    private final String timeSlot;
    private final HealthProfessional doctor;

    /**
     * Parameterized constructor: Initializes all appointment details
     * @param patientName Name of the patient
     * @param patientPhone Patient's contact phone number
     * @param timeSlot Scheduled appointment time
     * @param doctor Doctor assigned to the appointment
     */
    public Appointment(String patientName, String patientPhone, String timeSlot, HealthProfessional doctor) {
        this.patientName = patientName;
        this.patientPhone = patientPhone;
        this.timeSlot = timeSlot;
        this.doctor = doctor;
    }

    /**
     * Prints complete details of the appointment
     * Includes patient info, time slot, and associated doctor's info
     */
    public void printAppointmentInfo() {
        System.out.println("=== Appointment Details ===");
        System.out.println("Patient Name: " + patientName);
        System.out.println("Patient Phone: " + patientPhone);
        System.out.println("Time Slot: " + timeSlot);
        System.out.println("Doctor Info:");
        doctor.printInfo();
        System.out.println("------------------------------");
    }

    /**
     * Getter method for patient phone number (用于取消预约)
     */
    public String getPatientPhone() {
        return patientPhone;
    }
}