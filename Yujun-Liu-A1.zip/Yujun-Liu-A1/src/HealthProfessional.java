public class HealthProfessional {
    private String id;
    private String name;
    private String specialtyArea;

    public HealthProfessional(String id, String name, String specialtyArea) {
        this.id = id;
        this.name = name;
        this.specialtyArea = specialtyArea;
    }

    public void printInfo() {
        System.out.println("医生ID：" + id);
        System.out.println("姓名：" + name);
        System.out.println("专业领域：" + specialtyArea);
    }
}