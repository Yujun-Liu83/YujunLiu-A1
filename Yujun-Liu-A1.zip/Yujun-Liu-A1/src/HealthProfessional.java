/**
 * Base class representing a health professional (parent class for all doctor types)
 * Contains common properties and methods shared by all health professionals
 */
public class HealthProfessional {
    // Marked as final (does not modify after initialization)
    private final String id;
    private final String name;
    private final String specialtyArea;

    /**
     * Parameterized constructor: Initializes all properties with given values
     * @param id Unique identifier of the health professional
     * @param name Full name of the health professional
     * @param specialtyArea Medical specialty field
     */
    public HealthProfessional(String id, String name, String specialtyArea) {
        this.id = id;
        this.name = name;
        this.specialtyArea = specialtyArea;
    }

    /**
     * Prints basic information of the health professional
     * Outputs ID, name, and specialty area
     */
    public void printInfo() {
        System.out.println("=== Health Professional Basic Info ===");
        System.out.println("ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Specialty Area: " + specialtyArea);
    }

    /**
     * Getter method for name (used in appointment creation)
     */
    public String getName() {
        return name;
    }
}