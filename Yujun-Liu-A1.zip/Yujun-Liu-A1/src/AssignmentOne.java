import java.util.ArrayList;

public class AssignmentOne {
    public static void main(String[] args) {
        System.out.println("==================== 第3部分：卫生专业人员对象 ====================");
        // 创建3个全科医生对象
        GeneralPractitioner gp1 = new GeneralPractitioner("DR001", "张医生", "全科医学", 10);
        GeneralPractitioner gp2 = new GeneralPractitioner("DR002", "李医生", "全科医学", 8);
        GeneralPractitioner gp3 = new GeneralPractitioner("DR003", "王医生", "全科医学", 5);

        // 创建2个儿科医生对象
        Pediatrician p1 = new Pediatrician("DR004", "赵医生", "儿科", "0-6岁");
        Pediatrician p2 = new Pediatrician("DR005", "孙医生", "儿科", "7-12岁");

        // 打印所有医生的详细信息
        gp1.printInfo();
        gp2.printInfo();
        gp3.printInfo();
        p1.printInfo();
        p2.printInfo();

        System.out.println("------------------------------");

        // 第5部分 – 预约收集
        System.out.println("==================== 第5部分：预约管理 ====================");
        ArrayList<Appointment> appointmentList = new ArrayList<>();

        // 创建4个预约（2个全科，2个儿科）
        createAppointment(appointmentList, "张三", "13800138000", "08:30", gp1);
        createAppointment(appointmentList, "李四", "13900139000", "10:00", gp2);
        createAppointment(appointmentList, "王五", "13700137000", "14:30", p1);
        createAppointment(appointmentList, "赵六", "13600136000", "16:00", p2);

        // 打印现有预约
        System.out.println("1. 所有现有预约：");
        printExistingAppointments(appointmentList);

        // 取消一个预约
        System.out.println("2. 取消手机为13900139000的预约：");
        cancelBooking(appointmentList, "13900139000");

        // 再次打印预约
        System.out.println("3. 取消后的所有预约：");
        printExistingAppointments(appointmentList);
    }

    public static void createAppointment(ArrayList<Appointment> list, String patientName, String patientPhone, String timeSlot, HealthProfessional doctor) {
        if (patientName.isEmpty() || patientPhone.isEmpty() || timeSlot.isEmpty() || doctor == null) {
            System.out.println("预约失败：必需信息不完整！");
            return;
        }
        Appointment newAppointment = new Appointment(patientName, patientPhone, timeSlot, doctor);
        list.add(newAppointment);
        System.out.println("预约成功！患者：" + patientName + "，预约医生：" + doctor.getName());
    }

    public static void printExistingAppointments(ArrayList<Appointment> list) {
        if (list.isEmpty()) {
            System.out.println("当前没有任何预约！");
            return;
        }
        for (int i = 0; i < list.size(); i++) {
            System.out.println("第" + (i + 1) + "个预约：");
            list.get(i).printAppointmentInfo();
            System.out.println("------------------------------");
        }
    }

    public static void cancelBooking(ArrayList<Appointment> list, String patientPhone) {
        boolean found = false;
        for (int i = 0; i < list.size(); i++) {
            Appointment appointment = list.get(i);
            if (appointment.getPatientPhone().equals(patientPhone)) {
                list.remove(i);
                found = true;
                System.out.println("取消成功！已删除手机为" + patientPhone + "的预约");
                break;
            }
        }
        if (!found) {
            System.out.println("取消失败：未找到手机为" + patientPhone + "的预约");
        }
    }
}