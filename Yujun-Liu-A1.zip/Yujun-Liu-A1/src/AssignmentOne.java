import java.util.ArrayList;

/**
 * Main class containing the program entry point (main method)
 * Demonstrates object creation, inheritance, polymorphism, and appointment management
 */
public class AssignmentOne {
    /**
     * Main method: Entry point of the program
     */
    public static void main(String[] args) {
        // Part 3: Create and display health professional objects
        System.out.println("==================== Part 3: Health Professional Objects ====================");

        // Create 3 General Practitioner objects
        GeneralPractitioner gp1 = new GeneralPractitioner("DR001", "Dr. Zhang", "General Medicine", 10);
        GeneralPractitioner gp2 = new GeneralPractitioner("DR002", "Dr. Li", "General Medicine", 8);
        GeneralPractitioner gp3 = new GeneralPractitioner("DR003", "Dr. Wang", "General Medicine", 5);

        // Create 2 Pediatrician objects
        Pediatrician p1 = new Pediatrician("DR004", "Dr. Zhao", "Pediatrics", "0-6 Years");
        Pediatrician p2 = new Pediatrician("DR005", "Dr. Sun", "Pediatrics", "7-12 Years");

        // Print details of all health professionals
        gp1.printInfo();
        gp2.printInfo();
        gp3.printInfo();
        p1.printInfo();
        p2.printInfo();

        System.out.println("------------------------------");


        // Part 5: Manage appointments using ArrayList
        System.out.println("==================== Part 5: Appointment Management ====================");
        ArrayList<Appointment> appointmentList = new ArrayList<>();

        // Create 4 appointments
        createAppointment(appointmentList, "Zhang San", "13800138000", "08:30", gp1);
        createAppointment(appointmentList, "Li Si", "13900139000", "10:00", gp2);
        createAppointment(appointmentList, "Wang Wu", "13700137000", "14:30", p1);
        createAppointment(appointmentList, "Zhao Liu", "13600136000", "16:00", p2);

        // Print all existing appointments
        System.out.println("\n1. All Existing Appointments:");
        printExistingAppointments(appointmentList);

        // Cancel an appointment
        System.out.println("2. Perform Cancellation:");
        cancelBooking(appointmentList, "13900139000");

        // Print updated appointments
        System.out.println("\n3. Appointments After Cancellation:");
        printExistingAppointments(appointmentList);
    }

    /**
     * Creates a new appointment and adds it to the list
     */
    public static void createAppointment(ArrayList<Appointment> list, String patientName, String patientPhone, String timeSlot, HealthProfessional doctor) {
        if (patientName.isEmpty() || patientPhone.isEmpty() || timeSlot.isEmpty() || doctor == null) {
            System.out.println("Appointment Failed: Required Information Incomplete!");
            return;
        }
        Appointment newAppt = new Appointment(patientName, patientPhone, timeSlot, doctor);
        list.add(newAppt);
        System.out.println("Appointment Successful! Patient: " + patientName + ", Doctor: " + doctor.getName());
    }

    /**
     * Prints all appointments in the list
     */
    public static void printExistingAppointments(ArrayList<Appointment> list) {
        if (list.isEmpty()) {
            System.out.println("No Appointments Currently!");
            return;
        }
        for (int i = 0; i < list.size(); i++) {
            System.out.println("Appointment " + (i + 1) + ":");
            list.get(i).printAppointmentInfo();
        }
    }

    /**
     * Cancels an appointment by patient's phone number
     */
    public static void cancelBooking(ArrayList<Appointment> list, String targetPhone) {
        boolean isCancelled = false;
        for (int i = 0; i < list.size(); i++) {
            Appointment appt = list.get(i);
            if (appt.getPatientPhone().equals(targetPhone)) {
                list.remove(i);
                isCancelled = true;
                System.out.println("Cancellation Successful! Appointment with Phone " + targetPhone + " Deleted");
                break;
            }
        }
        if (!isCancelled) {
            System.out.println("Cancellation Failed: No Appointment Found with Phone " + targetPhone);
        }
    }
}