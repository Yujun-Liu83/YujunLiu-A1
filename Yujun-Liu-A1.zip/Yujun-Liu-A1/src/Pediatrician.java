// Pediatrician.java 完整代码
public class Pediatrician extends HealthProfessional {
    private String ageRange;

    public Pediatrician() {
        super();
        this.ageRange = "";
    }

    // 注意参数名与调用处一致，这里用 specialtyArea 对应“专业领域”
    public Pediatrician(String id, String name, String specialtyArea, String ageRange) {
        super(id, name, specialtyArea);
        this.ageRange = ageRange;
    }

    @Override
    public void printInfo() {
        System.out.println("=== 卫生专业人员类型：儿科医生 ===");
        super.printInfo();
        System.out.println("擅长年龄段：" + ageRange);
        System.out.println();
    }

    public String getAgeRange() {
        return ageRange;
    }
}