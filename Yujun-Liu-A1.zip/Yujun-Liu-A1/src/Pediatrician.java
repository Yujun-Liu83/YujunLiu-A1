/**
 * Subclass representing a Pediatrician (extends HealthProfessional)
 * Adds properties and methods specific to pediatricians (child doctors)
 */
public class Pediatrician extends HealthProfessional {
    // Marked as final (does not modify after initialization)
    private final String ageRange;

    /**
     * Parameterized constructor: Initializes all properties
     * @param id Unique identifier (inherited from parent)
     * @param name Full name (inherited from parent)
     * @param specialtyArea Medical specialty (e.g., "Pediatrics")
     * @param ageRange Specialized age range of patients
     */
    public Pediatrician(String id, String name, String specialtyArea, String ageRange) {
        super(id, name, specialtyArea);
        this.ageRange = ageRange;
    }

    /**
     * Overrides parent method to print complete info for pediatricians
     * Includes type identifier and specialized age range
     */
    @Override
    public void printInfo() {
        System.out.println("【Health Professional Type: Pediatrician】");
        super.printInfo();
        System.out.println("Age Range: " + ageRange);
        System.out.println();
    }
}