public class GeneralPractitioner extends HealthProfessional {
    private int workYears;

    public GeneralPractitioner(String id, String name, String specialtyArea, int workYears) {
        super(id, name, specialtyArea);
        this.workYears = workYears;
    }

    @Override
    public void printInfo() {
        super.printInfo();
        System.out.println("职业类型：全科医生");
        System.out.println("接诊年限：" + workYears + "年");
        System.out.println("---------------------");
    }

    public int getWorkYears() {
        return workYears;
    }
}