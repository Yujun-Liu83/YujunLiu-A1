/**
 * Subclass representing a General Practitioner (extends HealthProfessional)
 * Adds properties and methods specific to general practitioners
 */
public class GeneralPractitioner extends HealthProfessional {
    // Marked as final (does not modify after initialization)
    private final int consultationYears;

    /**
     * Parameterized constructor: Initializes all properties
     * @param id Unique identifier (inherited from parent)
     * @param name Full name (inherited from parent)
     * @param specialtyArea Medical specialty (e.g., "General Medicine")
     * @param consultationYears Years of consulting experience
     */
    public GeneralPractitioner(String id, String name, String specialtyArea, int consultationYears) {
        super(id, name, specialtyArea);
        this.consultationYears = consultationYears;
    }

    /**
     * Overrides parent method to print complete info for general practitioners
     * Includes type identifier and consultation years
     */
    @Override
    public void printInfo() {
        System.out.println("【Health Professional Type: General Practitioner】");
        super.printInfo();
        System.out.println("Consultation Years: " + consultationYears + " years");
        System.out.println();
    }
}